The main creates two player instances and then uses them for a game object. Then it plays the game and prints out the winner

Also, the game prints out a lot of information while the game plays. Most is self explanatory but the list of cards is only the second person's deck.

Finally, when the 1000 hand cap is reached the algorithm picks a winner and loops until it drains the hand of the loser.

In short, I got a single game of war to work.
